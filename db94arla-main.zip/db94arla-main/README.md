# db94arla
The purpose of this assignment is to become familiar with using pug templates to dynamically generate web pages on the server side

class: Lounge. Attributes: loungename,loungelocation,loungecapacity.

heroku hosted at : https://db94arla.herokuapp.com/

